#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <string>

using namespace std;

struct Expense {
    string category;
    double amount;
    string date;
};

class ExpenseTracker {
private:
    vector<Expense> expenses;

public:
    void addExpense() {
        Expense e;
        cout << "Enter category (e.g., Food, Travel): ";
        cin >> ws;
        getline(cin, e.category);

        cout << "Enter amount: ";
        cin >> e.amount;

        cout << "Enter date (DD-MM-YYYY): ";
        cin >> e.date;

        expenses.push_back(e);
        cout << "Expense added successfully.\n";
    }

    void viewExpenses() {
        if (expenses.empty()) {
            cout << "No expenses to show.\n";
            return;
        }

        cout << "\n--- All Expenses ---\n";
        cout << left << setw(15) << "Category" << setw(10) << "Amount" << "Date" << endl;
        for (const auto& e : expenses) {
            cout << left << setw(15) << e.category << setw(10) << e.amount << e.date << endl;
        }
    }

    void totalExpenses() {
        double total = 0;
        for (const auto& e : expenses)
            total += e.amount;

        cout << "Total Expenses: $" << total << endl;
    }

    void saveToFile() {
        ofstream fout("expenses.txt");
        if (!fout) {
            cerr << "Error opening file for writing.\n";
            return;
        }

        for (const auto& e : expenses) {
            fout << e.category << "," << e.amount << "," << e.date << "\n";
        }

        fout.close();
        cout << "Expenses saved to file.\n";
    }

    void loadFromFile() {
        ifstream fin("expenses.txt");
        if (!fin) {
            cerr << "No existing expense file found.\n";
            return;
        }

        expenses.clear();
        Expense e;
        string line;
        while (getline(fin, line)) {
            size_t pos1 = line.find(',');
            size_t pos2 = line.rfind(',');

            if (pos1 == string::npos || pos2 == string::npos || pos1 == pos2) continue;

            e.category = line.substr(0, pos1);
            e.amount = stod(line.substr(pos1 + 1, pos2 - pos1 - 1));
            e.date = line.substr(pos2 + 1);

            expenses.push_back(e);
        }

        fin.close();
        cout << "Expenses loaded from file.\n";
    }
};

int main() {
    ExpenseTracker tracker;
    int choice;

    tracker.loadFromFile();

    do {
        cout << "\n===== Expense Tracker Menu =====\n";
        cout << "1. Add Expense\n";
        cout << "2. View Expenses\n";
        cout << "3. View Total Expenses\n";
        cout << "4. Save to File\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: tracker.addExpense(); break;
            case 2: tracker.viewExpenses(); break;
            case 3: tracker.totalExpenses(); break;
            case 4: tracker.saveToFile(); break;
            case 0: cout << "Exiting..."; break;
            default: cout << "Invalid choice.\n";
        }
    } while (choice != 0);

    return 0;
}
