#include <iostream>
#include <cstdlib>
#include <ctime>
#include <thread>
#include <chrono>

using namespace std;

// Function to clear the console screen
void clearScreen() {
    system("clear");
}

// Function to generate a 3-digit random sequence
string generateSequence() {
    string sequence = "";
    for (int i = 0; i < 3; i++) {
        sequence += to_string(rand() % 10);
    }
    return sequence;
}

int main() {
    srand(time(0)); // Seed for random number generation

    cout << "Welcome to the 3-Digit Memory Game!" << endl;
    cout << "You will see a 3-digit number for 5 seconds.\n";

    string sequence = generateSequence();

    cout << "\nMemorize this: " << sequence << endl;

    // Wait for 5 seconds
    this_thread::sleep_for(chrono::seconds(5));

    clearScreen(); // Clear screen after showing sequence

    string guess;
    cout << "Enter the 3-digit number you remember: ";
    cin >> guess;

    if (guess == sequence) {
        cout << "Correct! Great memory! 🎉" << endl;
    } else {
        cout << "Oops! The correct sequence was: " << sequence << endl;
    }

    // Wait for user to press Enter before exiting
    cout << "PRESS ENTER TO EXIT\n";
    cin.ignore(); // Clear the newline character left in the input buffer
    cin.get();    // Wait for the user to press Enter

    return 0;
}
