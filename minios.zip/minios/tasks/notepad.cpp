#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main() {
    // Get the file name from the user
    cout << "Enter the file name to save notes (default: notes.txt): ";
    string fileName;
    getline(cin, fileName);

    // If user does not provide a file name, use the default
    if (fileName.empty()) {
        fileName = "notes.txt";
    }

    // Open the file in append mode
    ofstream myfile(fileName, ios::app);

    if (!myfile.is_open()) {
        cerr << "Error: Unable to open file " << fileName << endl;
        return 1;
    }

    cout << "MiniOS Notepad (type 'exit' to close)\n";

    string text;
    while (true) {
        cout << "> ";
        getline(cin, text);

        // Exit condition when user types 'exit'
        if (text == "exit") {
            break;
        }

        // Write the entered text to the file
        myfile << text << endl;
    }

    myfile.close();
    cout << "Notes saved to " << fileName << endl;
    cout<<"PRESS ENTER TO EXIT\n";
        cin.ignore();
    return 0;
}
