#include <iostream>
#include <string>
using namespace std;

int main() {
    string check;
    cout << "WELCOME TO GPA CALCULATOR\n";
    do {
        string cal;
        cout << "\nFOR SGPA PRESS s\n";
        cout << "FOR CGPA PRESS c\n";
        cin >> cal;

        if (cal == "c") {
            int nsemester;
            double sgpa, cgpa, sum = 0.0;
            cout << "HOW MANY SEMESTERS YOU WANT TO CALCULATE CGPA: ";
            cin >> nsemester;
            for (int i = 1; i <= nsemester; i++) {
                cout << "INPUT YOUR " << i << " SEMESTER GPA: ";
                cin >> sgpa;
                sum += sgpa;
            }
            cgpa = sum / nsemester;
            cout << "YOUR CGPA IS " << cgpa << endl;
        }

        else if (cal == "s") {
            int nsub, credit, creditsum = 0;
            double sgpa = 0.0, sum = 0.0;
            const double Aplus = 4.00, A = 4.00, Aneg = 3.67, Bplus = 3.33,
                         B = 3.00, Bneg = 2.67, Cplus = 2.33, C = 2.00, Cneg = 1.67,
                         Dplus = 1.33, D = 1.00, F = 0.00;

            string course, grade;
            cout << "ENTER NO. OF SUBJECTS: ";
            cin >> nsub;

            for (int i = 1; i <= nsub; i++) {
                cout << "ENTER COURSE " << i << " NAME: ";
                cin >> course;
                cout << "ENTER COURSE " << i << " CREDIT: ";
                cin >> credit;
                creditsum += credit;

                cout << "ENTER COURSE " << i << " GRADE: ";
                cin >> grade;

                if (grade == "A+" || grade == "a+" || grade == "Aplus" || grade == "aplus") {
                    sum += credit * Aplus;
                } else if (grade == "A" || grade == "a") {
                    sum += credit * A;
                } else if (grade == "A-" || grade == "a-" || grade == "Aneg" || grade == "aneg") {
                    sum += credit * Aneg;
                } else if (grade == "B+" || grade == "b+" || grade == "Bplus" || grade == "bplus") {
                    sum += credit * Bplus;
                } else if (grade == "B" || grade == "b") {
                    sum += credit * B;
                } else if (grade == "B-" || grade == "b-" || grade == "Bneg" || grade == "bneg") {
                    sum += credit * Bneg;
                } else if (grade == "C+" || grade == "c+" || grade == "Cplus" || grade == "cplus") {
                    sum += credit * Cplus;
                } else if (grade == "C" || grade == "c") {
                    sum += credit * C;
                } else if (grade == "C-" || grade == "c-" || grade == "Cneg" || grade == "cneg") {
                    sum += credit * Cneg;
                } else if (grade == "D+" || grade == "d+" || grade == "Dplus" || grade == "dplus") {
                    sum += credit * Dplus;
                } else if (grade == "D" || grade == "d") {
                    sum += credit * D;
                } else if (grade == "F" || grade == "f") {
                    sum += credit * F;
                } else {
                    cout << "INVALID GRADE! Again Input\n";
                    i--; // Repeat this iteration
                    continue;
                }
                cout << endl;
            }

            sgpa = sum / creditsum;
            cout << "YOUR SGPA IS " << sgpa << endl;
        }

        else {
            cout << "\nINVALID INPUT! TRY AGAIN.\n";
            continue;
        }

        cout << "TO USE AGAIN PRESS y ELSE ANY KEY: ";
        cin >> check;

    } while (check == "y" || check == "Y");

    cout << "THANKS FOR USING GPA CALCULATOR\n";
    cin.get(); 
    system("pause");
    return 0;
}
