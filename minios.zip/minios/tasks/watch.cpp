#include <iostream>
#include <ctime>
#include <iomanip> // for std::setw and std::setfill
#include <thread>  // for std::this_thread::sleep_for
#include <chrono>  // for std::chrono::seconds>
#include <termios.h> // for non-blocking input
#include <unistd.h>  // for STDIN_FILENO

using namespace std;

// Function to enable non-blocking input
void enableNonBlockingInput() {
    termios t;
    tcgetattr(STDIN_FILENO, &t);
    t.c_lflag &= ~ICANON; // Disable canonical mode
    t.c_lflag &= ~ECHO;   // Disable echo
    tcsetattr(STDIN_FILENO, TCSANOW, &t);
}

// Function to disable non-blocking input
void disableNonBlockingInput() {
    termios t;
    tcgetattr(STDIN_FILENO, &t);
    t.c_lflag |= ICANON; // Enable canonical mode
    t.c_lflag |= ECHO;   // Enable echo
    tcsetattr(STDIN_FILENO, TCSANOW, &t);
}

int main() {
    string command;
    enableNonBlockingInput(); // Enable non-blocking input

    while (true) {
        // Get current time as time_t object
        time_t now = time(0);

        // Convert to local time structure
        tm *localTime = localtime(&now);

        // Clear the console (platform-specific for Linux/WSL)
        system("clear");

        // Display the current time
        cout << "Current Time: ";
        cout << setw(2) << setfill('0') << localTime->tm_hour << ":"
             << setw(2) << setfill('0') << localTime->tm_min << ":"
             << setw(2) << setfill('0') << localTime->tm_sec << endl;

        // Check if the user wants to exit
        if (cin.rdbuf()->in_avail() > 0) { // Check if input is available
            cin >> command;
            if (command == "exit") break;
        }

        // Wait for 1 second before updating the time
        this_thread::sleep_for(chrono::seconds(1));
    }

    disableNonBlockingInput(); // Restore blocking input
    
    return 0;
}
