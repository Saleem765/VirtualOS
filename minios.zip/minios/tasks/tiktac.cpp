#include <iostream>
#include <limits>
#include <string>

using namespace std;

char board[3][3];
string player1, player2;
int moveCount = 0;
char currentPlayerSymbol;

void initializeBoard() {
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            board[i][j] = '-';
}

void displayBoard() {
    cout << "\n   0   1   2\n";
    for (int i = 0; i < 3; ++i) {
        cout << i << " ";
        for (int j = 0; j < 3; ++j) {
            cout << " " << board[i][j];
            if (j < 2) cout << " |";
        }
        cout << "\n";
        if (i < 2) cout << "  ---+---+---\n";
    }
    cout << endl;
}

bool isWin(char symbol) {
    for (int i = 0; i < 3; ++i)
        if ((board[i][0] == symbol && board[i][1] == symbol && board[i][2] == symbol) ||
            (board[0][i] == symbol && board[1][i] == symbol && board[2][i] == symbol))
            return true;

    if ((board[0][0] == symbol && board[1][1] == symbol && board[2][2] == symbol) ||
        (board[0][2] == symbol && board[1][1] == symbol && board[2][0] == symbol))
        return true;

    return false;
}

bool isDraw() {
    return moveCount == 9;
}

void switchPlayer() {
    currentPlayerSymbol = (currentPlayerSymbol == 'X') ? 'O' : 'X';
}

void playGame() {
    int row, col;
    string currentPlayerName = player1;
    currentPlayerSymbol = 'X';
    moveCount = 0;
    initializeBoard();

    while (true) {
        displayBoard();
        cout << currentPlayerName << "'s turn (" << currentPlayerSymbol << "). Enter row and column (0-2): ";
        cin >> row >> col;

        if (cin.fail() || row < 0 || row > 2 || col < 0 || col > 2) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter numbers between 0 and 2.\n";
            continue;
        }

        if (board[row][col] != '-') {
            cout << "Cell already occupied. Try again.\n";
            continue;
        }

        board[row][col] = currentPlayerSymbol;
        moveCount++;

        if (isWin(currentPlayerSymbol)) {
            displayBoard();
            cout << currentPlayerName << " wins!\n";
            break;
        }

        if (isDraw()) {
            displayBoard();
            cout << "It's a draw!\n";
            break;
        }

        switchPlayer();
        currentPlayerName = (currentPlayerSymbol == 'X') ? player1 : player2;
    }
}

int main() {
    char playAgain;

    cout << "Welcome to Tic-Tac-Toe!\n";
    cout << "Enter Player 1 name: ";
    getline(cin, player1);
    cout << "Enter Player 2 name: ";
    getline(cin, player2);

    do {
        playGame();
        cout << "Do you want to play again? (y/n): ";
        cin >> playAgain;
        cin.ignore();
    } while (playAgain == 'y' || playAgain == 'Y');

    cout << "Thank you for playing!\n";
    cout<<"PRESS ENTER TO EXIT\n";
        cin.ignore();
        cin.get(); 
    return 0;
}
