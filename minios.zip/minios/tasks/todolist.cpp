#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;

vector<string> tasks;

// Load tasks from file
void loadTasks() {
    tasks.clear();
    ifstream file("tasks.txt");
    string line;
    while (getline(file, line)) {
        tasks.push_back(line);
    }
    file.close();
}

// Save tasks to file
void saveTasks() {
    ofstream file("tasks.txt");
    for (const auto& task : tasks) {
        file << task << endl;
    }
    file.close();
}

// Display all tasks
void viewTasks() {
    cout << "\nTo-Do List:\n";
    if (tasks.empty()) {
        cout << "  No tasks yet.\n";
    } else {
        for (size_t i = 0; i < tasks.size(); ++i) {
            cout << "  " << i + 1 << ". " << tasks[i] << endl;
        }
    }
}

// Add a new task
void addTask() {
    cin.ignore(); // Clear newline buffer
    string task;
    cout << "Enter new task: ";
    getline(cin, task);
    tasks.push_back(task);
    saveTasks();
    cout << "Task added!\n";
}

// Delete a task
void deleteTask() {
    int index;
    viewTasks();
    cout << "Enter task number to delete: ";
    cin >> index;
    if (index >= 1 && index <= tasks.size()) {
        tasks.erase(tasks.begin() + index - 1);
        saveTasks();
        cout << "Task deleted!\n";
    } else {
        cout << "Invalid task number.\n";
    }
}

int main() {
    int choice;
    loadTasks();

    do {
        cout << "\n==== TO-DO LIST MENU ====\n";
        cout << "1. View Tasks\n";
        cout << "2. Add Task\n";
        cout << "3. Delete Task\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1: viewTasks(); break;
            case 2: addTask(); break;
            case 3: deleteTask(); break;
            case 0: cout << "Goodbye!\n"; break;
            default: cout << "Invalid choice!\n";
        }

    } while (choice != 0);
    cout<<"PRESS ENTER TO EXIT\n";
    cin.ignore();
    cin.get(); 
    return 0;
}
