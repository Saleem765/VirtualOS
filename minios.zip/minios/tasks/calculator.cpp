#include <iostream>
using namespace std;

int main() {
    // Display a welcome message for the calculator
    cout << "MiniOS Calculator (type 'exit' to quit)\n";

    while (true) {
        // Prompt the user to enter an operation
        cout << "Enter operation (e.g., 5 + 3): ";
        double a, b; // Variables to store operands
        char op;     // Variable to store the operator
        cin >> a >> op >> b;

        // Handle invalid input or exit command
        if (cin.fail()) {
            cin.clear(); // Clear the error flag
            string exitCommand;
            cin >> exitCommand; // Read the remaining input
            if (exitCommand == "exit") break; // Exit the loop if "exit" is entered
            cerr << "Invalid input. Try again.\n"; // Display an error message
            continue; // Restart the loop
        }

        // Perform the operation based on the operator
        switch (op) {
            case '+': 
                cout << "Result: " << (a + b) << endl; // Addition
                break;
            case '-': 
                cout << "Result: " << (a - b) << endl; // Subtraction
                break;
            case '*': 
                cout << "Result: " << (a * b) << endl; // Multiplication
                break;
            case '/': 
                if (b != 0) 
                    cout << "Result: " << (a / b) << endl; // Division
                else 
                    cerr << "Error: Division by zero.\n"; // Handle division by zero
                break;
            default: 
                cerr << "Invalid operator. Try again.\n"; // Handle invalid operator
        }
    }

    return 0; // Exit the program
}