#include <iostream>
#include <vector>
#include <string>
using namespace std;

// Class to represent a Candidate
class Candidate {
public:
    string name;
    int votes;

    Candidate(string name) {
        this->name = name;
        votes = 0;
    }

    void addVote() {
        votes++;
    }

    void display() {
        cout << name << " - " << votes << " votes" << endl;
    }
};

// Function to display the available candidates
void displayCandidates(vector<Candidate>& candidates) {
    cout << "Available candidates:" << endl;
    for (int i = 0; i < candidates.size(); i++) {
        cout << i + 1 << ". " << candidates[i].name << endl;
    }
}

// Main function
int main() {
    int numCandidates, totalVotes;
    vector<Candidate> candidates;

    // Input number of candidates
    cout << "Enter number of candidates: ";
    cin >> numCandidates;

    // Input candidate names
    for (int i = 0; i < numCandidates; i++) {
        string candidateName;
        cout << "Enter name of candidate " << i + 1 << ": ";
        cin >> ws;  // to ignore any leading whitespace
        getline(cin, candidateName);  // to allow spaces in the name
        candidates.push_back(Candidate(candidateName));
    }

    // Input number of voters
    cout << "Enter total number of voters: ";
    cin >> totalVotes;

    // Voting process
    for (int i = 0; i < totalVotes; i++) {
        int choice;
        displayCandidates(candidates);
        cout << "Enter your vote (1 to " << numCandidates << "): ";
        cin >> choice;

        if (choice >= 1 && choice <= numCandidates) {
            candidates[choice - 1].addVote();
        } else {
            cout << "Invalid choice! Vote not counted." << endl;
        }
    }

    // Display results
    cout << "\nVoting Results:" << endl;
    for (int i = 0; i < candidates.size(); i++) {
        candidates[i].display();
    }

    // Find the winner
    int winnerIndex = 0;
    for (int i = 1; i < candidates.size(); i++) {
        if (candidates[i].votes > candidates[winnerIndex].votes) {
            winnerIndex = i;
        }
    }

    cout << "\nThe winner is: " << candidates[winnerIndex].name << " with " 
         << candidates[winnerIndex].votes << " votes." << endl;
         cout<<"PRESS ENTER TO EXIT\n";
         cin.ignore();
         cin.get(); 
    return 0;
}
