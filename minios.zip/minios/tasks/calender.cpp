#include <iostream>
#include <iomanip>
#include <string> // For std::string
using namespace std;

// Function to check if year is leap
bool isLeap(int year) {
    return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
}

// Function to get number of days in a month
int getDaysInMonth(int month, int year) {
    switch (month) {
        case 2: return isLeap(year) ? 29 : 28;
        case 4: case 6: case 9: case 11: return 30;
        default: return 31;
    }
}

// Function to get the day of the week for the 1st day of a month
// Uses Zeller's Congruence algorithm
int getStartDay(int month, int year) {
    if (month < 3) {
        month += 12;
        year--;
    }
    int q = 1;
    int k = year % 100;
    int j = year / 100;

    int h = (q + 13 * (month + 1) / 5 + k + k / 4 + j / 4 + 5 * j) % 7;
    return (h + 6) % 7; // Convert to 0=Sunday, 6=Saturday
}

// Function to display the calendar
void displayCalendar(int month, int year) {
    string months[] = {
        "", "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    };

    int days = getDaysInMonth(month, year);
    int start = getStartDay(month, year);

    cout << "\n  " << months[month] << " " << year << endl;
    cout << "  Su Mo Tu We Th Fr Sa" << endl;

    int day = 1;
    int currentPos = 0;

    // Print initial spaces
    for (int i = 0; i < start; ++i) {
        cout << "   ";
        currentPos++;
    }

    // Print days of the month
    while (day <= days) {
        cout << setw(3) << day;
        currentPos++;
        if (currentPos % 7 == 0) {
            cout << endl;
        }
        day++;
    }

    cout << endl;
}

int main() {
    while (true) {
        string input;
        int month, year;
        cout << "Enter month (1-12): ";
        cin >> month;

        cout << "Enter year: ";
        cin >> year;



        displayCalendar(month, year);

       
        cout<<"PRESS ENTER TO EXIT\n";
        cin.ignore();
        cin.get(); 
         // Clear the newline character from the input buffer
    }

    return 0;
}
