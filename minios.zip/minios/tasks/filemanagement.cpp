#include <iostream>
#include <fstream>
#include <cstdio>  // For remove()
using namespace std;

// Create a new file
void createFile(const string& filename) {
    ofstream file(filename);
    if (file) {
        cout << "File created: " << filename << endl;
        file.close();
    } else {
        cout << "Error creating file.\n";
    }
}

// Write to an existing file (overwrites content)
void writeFile(const string& filename) {
    ofstream file(filename);
    if (!file) {
        cout << "Error opening file for writing.\n";
        return;
    }

    string content;
    cout << "Enter text to write (end with a single line with 'END'):\n";
    while (true) {
        getline(cin, content);
        if (content == "END") break;
        file << content << endl;
    }

    cout << "Data written to file.\n";
    file.close();
}

// Read contents of a file
void readFile(const string& filename) {
    ifstream file(filename);
    if (!file) {
        cout << "File not found.\n";
        return;
    }

    string line;
    cout << "File contents:\n";
    while (getline(file, line)) {
        cout << line << endl;
    }
    file.close();
}

// Delete a file
void deleteFile(const string& filename) {
    if (remove(filename.c_str()) == 0) {
        cout << "File deleted: " << filename << endl;
    } else {
        cout << "Error deleting file.\n";
    }
}

// Main function with basic menu
int main() {
    int choice;
    string filename;

    do {
        cout << "\nFile Operations Menu\n";
        cout << "1. Create File\n";
        cout << "2. Write File\n";
        cout << "3. Read File\n";
        cout << "4. Delete File\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        cin.ignore();  // To handle newline

        switch (choice) {
            case 1:
                cout << "Enter filename: ";
                getline(cin, filename);
                createFile(filename);
                break;

            case 2:
                cout << "Enter filename: ";
                getline(cin, filename);
                writeFile(filename);
                break;

            case 3:
                cout << "Enter filename: ";
                getline(cin, filename);
                readFile(filename);
                break;

            case 4:
                cout << "Enter filename: ";
                getline(cin, filename);
                deleteFile(filename);
                break;

            case 0:
                cout << "Exiting program.\n";
                break;

            default:
                cout << "Invalid choice.\n";
        }

    } while (choice != 0);

    return 0;
}
