#include <iostream>
#include <thread>   // for sleep_for
#include <chrono>   // for chrono literals
#include <vector>
#include <unistd.h> // for fork(), execl(), sleep(), kill()
#include <sys/wait.h> // for wait()
#include<algorithm>
#include <string>
#include <sys/types.h> // for pid_t
#include <sys/stat.h> // for stat()
#include <fcntl.h> // for open()
#include <cstring> // for memset
#include <signal.h> // for SIGKILL
#include <queue>
#include <condition_variable>
#include <semaphore.h> // for semaphores
using namespace std;

//color set for menu
#define RESET   "\033[0m"
#define CYAN    "\033[36m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define MAGENTA "\033[35m"
#define RED     "\033[31m"
#define BOLD    "\033[1m"

// MemoryManager class to allocate and deallocte  RAM and HDD resources
class MemoryManager {
private:
    int totalRAM;     // Total RAM in MB
    int usedRAM;      // Used RAM in MB
    int totalHDD;     // Total Hard Drive in MB
    int usedHDD;      // Used Hard Drive in MB

public:
//constructor to initialize memory manager
    MemoryManager(int ramSizeMB, int hddSizeMB) {
        totalRAM = ramSizeMB;
        usedRAM = 0;
        totalHDD = hddSizeMB;
        usedHDD = 0;
    }
 //function to allocate memory of task
    bool allocateMemory(int ramNeeded, int hddNeeded) {
        if (usedRAM + ramNeeded <= totalRAM && usedHDD + hddNeeded <= totalHDD) {
            usedRAM += ramNeeded;
            usedHDD += hddNeeded;
            return true; // Memory successfully allocated
        }
        return false; // Not enough memory
    }
//function to free memory of task
    void freeMemory(int ramFreed, int hddFreed) {
        usedRAM -= ramFreed;
        usedHDD -= hddFreed;

        // Safety checks
        if (usedRAM < 0) usedRAM = 0;
        if (usedHDD < 0) usedHDD = 0;
    }
//function to get free RAM and HDD
    int getFreeRAM() const {
        return totalRAM - usedRAM;
    }
//function to get free HDD
    int getFreeHDD() const {
        return totalHDD - usedHDD;
    }
    //function to display memory status
    void displayMemoryStatus() const {
        cout<<CYAN<<endl;
        cout << "---------------------------" <<endl;
        cout << "Memory Status:" << endl;
        cout << "Total RAM: " << totalRAM << " MB" << endl;
        cout << "Used RAM: " << usedRAM << " MB" << endl;
        cout << "Free RAM: " << getFreeRAM() << " MB" << endl;
        cout << "Total Hard Drive: " << totalHDD << " MB" << endl;
        cout << "Used Hard Drive: " << usedHDD << " MB" << endl;
        cout << "Free Hard Drive: " << getFreeHDD() << " MB" << endl;
        cout << "---------------------------" << endl;
        cout<<RESET<<endl;
    }
};

// Task class for simulating a task
class Task {
private:
    string taskName;
    int ramNeeded;
    int hddNeeded;
    string state; // "Running" or "Minimized"
    pid_t pid;    // Process ID of the task
    
public:
//constructor to initialize task
    Task(string name, int ram, int hdd, pid_t processId)
        : taskName(name), ramNeeded(ram), hddNeeded(hdd), state("Running"), pid(processId) {}
//seters and getters for task class
    string getTaskName() const {
        return taskName;
    }

    int getRamNeeded() const {
        return ramNeeded;
    }

    int getHddNeeded() const {
        return hddNeeded;
    }

    string getState() const {
        return state;
    }

    void setState(string newState) {
        state = newState;
    }

    pid_t getPid() const {
        return pid;
    }
};

// OperatingSystem class to manage tasks and resources and core to run task 
class OperatingSystem {
private:
string osName;
int ramSize;
int hddSize;
int cores;
queue<Task> readyQueue; // Queue for ready tasks
vector<Task> runningTasks;// Vector for running tasks
sem_t coreSemaphore; // Semaphore for core access 

MemoryManager memoryManager; // Memory manager instance

vector<thread> coreThreads; // Threads representing CPU cores
queue<Task> taskQueue;      // Task queue for scheduling

sem_t queueAccess;  // Semaphore for queue access
sem_t tasksAvailable; // Semaphore for task availability

condition_variable cv;      // Condition variable for task scheduling
bool stopScheduling = false;

public:
//constructor to initialize operating system
OperatingSystem(string name, int ram, int hdd, int coreCount)
: osName(name), ramSize(ram), hddSize(hdd), cores(coreCount), memoryManager(ram, hdd) {
    // Initialize semaphores
    sem_init(&coreSemaphore, 0, cores);
    sem_init(&queueAccess, 0, 1);               
    sem_init(&tasksAvailable, 0, 0); 
    
}

//function to shutdown the operating system
    ~OperatingSystem() {
        sem_destroy(&coreSemaphore);
        sem_destroy(&queueAccess);
        sem_destroy(&tasksAvailable);
        
        // Stop scheduling and join threads
        sem_wait(&queueAccess);
        // Removed undefined 'task' variable
        sem_post(&queueAccess);

        stopScheduling = true;
        
        // Post 'tasksAvailable' to wake all core workers
        for (int i = 0; i < cores; ++i) {
            sem_post(&tasksAvailable);
        }

        // Join threads
        for (auto& thread : coreThreads) {
            if (thread.joinable()) {
                thread.join();
            }
        }
    }
    //function to run core worker threads
    void coreWorker(int coreId) {
        while (true) {
            sem_wait(&tasksAvailable);       // wait for a task to be available
            sem_wait(&queueAccess);          // lock access to queue
    
            if (stopScheduling && taskQueue.empty()) {
                sem_post(&queueAccess);
                return;
            }
    
            Task task = taskQueue.front();
            taskQueue.pop();
    
            sem_post(&queueAccess);          // unlock access to queue
    
            // Simulate task execution
            cout << "Core " << coreId << " is executing task: " << task.getTaskName() << endl;
            this_thread::sleep_for(chrono::seconds(2));
        }
    }
    
    
  
   
  //function to start a task
    bool startTask(string taskName, int ramNeeded, int hddNeeded, int oldtask = 0, bool fromReadyQueue = false) {
        if (!fromReadyQueue) {
            // Check memory first
            if (!memoryManager.allocateMemory(ramNeeded, hddNeeded)) {
                cout << "Not enough memory to start " << taskName << "!" << endl;
                return false;
            }
    
            // Try to acquire core slot via semaphore
            if (sem_trywait(&coreSemaphore) != 0) {
                // All cores are busy → move to ready queue
                Task task(taskName, ramNeeded, hddNeeded, -1);
                readyQueue.push(task);
                cout << taskName << " moved to Ready Queue (all cores busy).\n";
                memoryManager.freeMemory(ramNeeded, hddNeeded); // Temporarily release until it's picked
                return false;
            }
        }
    
        // Function to switch to kernel mode and manage tasks

        // Fork a new process for the task
        pid_t pid = fork();
        if (pid < 0) {
            cerr << "Fork failed for task: " << taskName << endl;
            if (!fromReadyQueue) {
                memoryManager.freeMemory(ramNeeded, hddNeeded);
                sem_post(&coreSemaphore);
            }
            return false;
        }
    // If child process
        if (pid == 0) {
            if (pid == 0) {
                string path = "../build/" + taskName;
                string command = "cmd.exe /c start \"\" wsl.exe " + path;
                execl("/bin/bash", "bash", "-c", command.c_str(), (char*)NULL);
                cout << "Failed to launch task in Windows terminal\n";
                _exit(1);
            }
            

        }
        // If parent process 
        else {
            Task task(taskName, ramNeeded, hddNeeded, pid);
            if (oldtask == 0)
                runningTasks.push_back(task);
            
           
    
            int status;
            waitpid(pid, &status, 0); // wait for termination or suspend
    
            while (true) {
                cout<<YELLOW;
                cout << "\n-----MENU FOR  " << taskName << "------\n";
                cout << "1. Minimize Task\n";
                cout << "2. Exit Task\n";
                cout << "3. Switch to Another Task\n";
                cout<<"--------------------------------\n";
                cout << "choice:";
                cout<<RESET;
                string choice;
                cin >> choice;
    
                if (choice == "1") {
                    kill(pid, SIGSTOP);
                    task.setState("Minimized");
                    cout << taskName << " minimized.\n";
                    return true;
                } else if (choice == "2") {
                    kill(pid, SIGKILL);
                    memoryManager.freeMemory(ramNeeded, hddNeeded);
                    sem_post(&coreSemaphore); // Free core slot
    
                    // Remove task from running queue
                    runningTasks.erase(remove_if(runningTasks.begin(), runningTasks.end(),
                        [pid](const Task& t) { return t.getPid() == pid; }), runningTasks.end());
    
                    cout << taskName << " exited. Resources freed.\n";
    
                    // Check ready queue and start next task
                    if (!readyQueue.empty()) {
                        Task next = readyQueue.front();
                        readyQueue.pop();
    
                        //Allocate memory again (as we freed it earlier)
                        if (memoryManager.allocateMemory(next.getRamNeeded(), next.getHddNeeded())) {
                            sem_wait(&coreSemaphore); // Acquire a free core
                            startTask(next.getTaskName(), next.getRamNeeded(), next.getHddNeeded(), 0, true);
                        } else {
                            cout << "Not enough memory to start task from Ready Queue: " << next.getTaskName() << endl;
                            readyQueue.push(next); // Push back if memory allocation fails
                        }
                    }
                    return true;
                } else if (choice == "3") {
                    cout<<RED;
                    cout << "\n------------Running Tasks------\n";
                    int index = 1;
                    vector<Task> availableTasks;
                    for (const auto& t : runningTasks) {
                        if (t.getPid() != pid) { // exclude current task
                            cout << index << ". " << t.getTaskName() <<"\n";
                            availableTasks.push_back(t);
                            index++;
                        }
                       

                    }
                    cout << "--------------------------------\n";
                    if (availableTasks.empty()) {
                        cout << "No other tasks available to switch.\n";
                        continue;
                    }
            
                    cout << "Enter the number of the task to switch to: ";
                    int switchChoice;
                    cin >> switchChoice;
            
                    if (switchChoice >= 1 && switchChoice <= availableTasks.size()) {
                        kill(pid, SIGSTOP); // Pause current task
                        task.setState("Minimized");
            
                        Task& selectedTask = availableTasks[switchChoice - 1];
                        pid_t selectedPid = selectedTask.getPid();
                        kill(selectedPid, SIGCONT); // Resume selected task
                        selectedTask.setState("Running");
            
                        cout << "Switched to: " << selectedTask.getTaskName() <<"\n";
                        cout<<RESET;
                        startTask(selectedTask.getTaskName(), 0,0,1); // Start the selected task
                        return true; // Control returns to main to handle the selected task
                    } 
                } else {
                    cout << "Invalid choice. Please try again.\n";
                }
                
            }
        }
    
        return true;
    }
    //function to boot the operating system
    void boot() {
        
        cout<<GREEN;
        cout << "--------System Information----------" << endl;
        cout<<RESET;
        cout<<CYAN;
        cout << "Operating System: " << osName << endl;
        cout << "RAM Size: " << ramSize << " MB" << endl;
        cout << "Hard Drive Size: " << hddSize << " MB" << endl;
        cout << "CPU Cores: " << cores << endl;
        cout << "-----------------------------------" << endl;
        cout<<RESET;

        // Start core threads
        for (int i = 0; i < cores; ++i) {
            coreThreads.emplace_back(&OperatingSystem::coreWorker, this, i);
        }
    }
    //function to close a task that is in ruuning queue
    void closeTask(string taskName) {
        bool taskFound = false;
    
        for (auto it = runningTasks.begin(); it != runningTasks.end(); ++it) {
            if (it->getTaskName() == taskName) {
                kill(it->getPid(), SIGKILL); // Kill the process
                memoryManager.freeMemory(it->getRamNeeded(), it->getHddNeeded()); // Free memory
                sem_post(&coreSemaphore); // Free core
                runningTasks.erase(it); // Remove from running list
                cout << taskName << " closed successfully!" << endl;
                taskFound = true;
                break;
            }
        }
    
        if (taskFound && !readyQueue.empty()) {
            Task next = readyQueue.front();
            readyQueue.pop();
    
            // Allocate memory again for the ready task
            if (memoryManager.allocateMemory(next.getRamNeeded(), next.getHddNeeded())) {
                sem_wait(&coreSemaphore); // Wait for a core
                startTask(next.getTaskName(), next.getRamNeeded(), next.getHddNeeded(), 0, true);
            } else {
                cout << "Not enough memory to start task from Ready Queue: " << next.getTaskName() << endl;
                readyQueue.push(next); // Push back if memory allocation fails
            }
        }
    
        if (!taskFound) {
            cout << taskName << " not found!" << endl;
        }
    }
    
    
   // function to switch between tasks 
    void switchTask() {
        string taskName;
        cout << "Enter the name of the task to switch to: ";
        cin.ignore();
        getline(cin, taskName);
    
        pid_t currentPid = -1;
        pid_t targetPid = -1;
    
        // Find current and target PIDs
        for (auto& task : runningTasks) {
            if (task.getState() == "Running") {
                currentPid = task.getPid();
            }
            if (task.getTaskName() == taskName && task.getState() != "Minimized") {
                targetPid = task.getPid();
            }
        }
    
        if (targetPid == -1) {
            cout << "Task '" << taskName << "' not found or minimized.\n";
            return;
        }
       
    
        // Pause current task
        for (auto& task : runningTasks) {
            if (task.getPid() == currentPid) {
                kill(currentPid, SIGSTOP);
                task.setState("Minimized");
                break;
            }
        }
    
        // Resume target task
        for (auto& task : runningTasks) {
            if (task.getPid() == targetPid) {
                kill(targetPid, SIGCONT);
                task.setState("Running");
                cout << "Switched to: " << task.getTaskName() << "\n";
                startTask(task.getTaskName(), 0,0,1);
                break;
            }
        }
    }
    
        
   


    //function to show running tasks in the system
    void showRunningTasks() {
        cout<<RED;
        cout << "\n------Running Tasks--------" << endl;
        for (const auto& task : runningTasks) {
            
            cout << task.getTaskName() << endl;
        }
        cout<<RESET;
       

    }

    void showMemoryStatus() {
        memoryManager.displayMemoryStatus();
    }
    void userToKernelMode() {
        cout<<RED;
        cout << "\n-------KERNAL MODE-----------\n";
        int usedcores=0;
        cout<<RESET;
        // Display running tasks
        cout<<YELLOW;
        cout << "---------Running Tasks--------\n";
        if (runningTasks.empty()) {
            cout << "No running tasks.\n";
        } else {
            for (const auto& task : runningTasks) {
                cout << "Task Name: " << task.getTaskName()
                     << " (PID: " << task.getPid() << ", State: " << task.getState() << ")\n";
                     usedcores++;
            }
        }
        cout<<RESET;
        cout<<YELLOW;
        cout<<"------------------------------\n";
        cout<<"TOTAL PROCESSORS:"<<cores<<endl;
        cout<<"USED PROCESSORS:"<<usedcores<<endl;
        cout<<"------------------------------\n";
        cout<<RESET;
        cout<<GREEN;
        // Display tasks in the ready queue
        cout << "\n----------Ready Queue Tasks-------\n";
        if (readyQueue.empty()) {
            cout << "No tasks in the ready queue.\n";
        } else {
            queue<Task> tempQueue = readyQueue; // Create a temporary copy of the queue
            while (!tempQueue.empty()) {
                Task task = tempQueue.front();
                tempQueue.pop();
                cout << "Task Name: " << task.getTaskName()
                     << " (PID: " << task.getPid() << ")\n";
            }
        }
        cout<<RESET;
        // Allow the user to delete tasks from the ready queue
        while (true) {
            cout<< "\n-----------Kernel Mode Menu---------\n";
            cout << "1. Delete a task from the ready queue\n";
            cout << "2. Exit Kernel Mode\n";
            cout << "Enter your choice: ";
            char choice;
            cin >> choice;
    
            if (choice == '1') {
                if (readyQueue.empty()) {
                    cout << "The ready queue is empty. No tasks to delete.\n";
                    continue;
                }
    
                cout << "TASK ANME TO REMOVE FROM READY QUEUE:";
                string taskName;
                cin >> taskName;
    
                queue<Task> tempQueue;
                bool taskFound = false;
    
                // Remove the task from the ready queue
                while (!readyQueue.empty()) {
                    Task task = readyQueue.front();
                    readyQueue.pop();
                    if (task.getTaskName() == taskName) {
                        taskFound = true;
                        cout << "Task " << taskName << " removed from the ready queue.\n";
                    } else {
                        tempQueue.push(task);
                    }
                }
    
                // Restore the remaining tasks to the ready queue
                readyQueue = tempQueue;
    
                if (!taskFound) {
                    cout << "Task " << taskName << " not found in the ready queue.\n";
                }
            } else if (choice == '2') {
                cout << "Exiting Kernel Mode...\n";
                break;
            } else {
                cout << "Invalid choice. Please try again.\n";
            }
        }
    }
};

int ramSizeGB, hddSizeGB; // Global variables for RAM and HDD sizes
int main(int argc, char* argv[]) {
    string choice="0";
    
        
    string osName = "MiniOS";  // You can name it anything you want
     cout<<"ENTER OPERATING SYSTEM NAME:";
    cin>>osName;
    cout << "Booting " << osName;
    
    // Loading animation with 3 dots
    for (int i = 0; i < 3; ++i) {
        cout << ".";
        this_thread::sleep_for(chrono::seconds(1));
    }

    cout << "\nWelcome to " << osName << "!\n";
    this_thread::sleep_for(chrono::seconds(2)); // Pause before continuing
     int ramSizeMB, hddSizeMB;
   
     ramSizeGB= atoi(argv[1]);
     hddSizeGB= atoi(argv[2]);
    int cores = atoi(argv[3]);

     
   

    // Convert GB to MB
    ramSizeMB = ramSizeGB * 1024;
    hddSizeMB = hddSizeGB * 1024;
  

    

    // Create the Operating System object
    OperatingSystem os(osName, ramSizeMB, hddSizeMB, cores);
    

    bool running = true;
    while (running) {
        cout << CYAN << "\n==========================================================" << RESET << endl;
        cout << BOLD << GREEN << "             🖥  MINI OPERATING SYSTEM MENU              " << RESET << endl;
        cout << CYAN << "==========================================================" << RESET << endl;

        cout << YELLOW;
        cout << " 1.  Start Notepad             12. Start School System" << endl;
        cout << " 2.  Start Calculator          13. Start TikTac" << endl;
        cout << " 3.  Memory Game               14. Start Voting System" << endl;
        cout << " 4.  Start To-Do List          15. Show Running Tasks" << endl;
        cout << " 5.  Start Tower of Hanoi      16. Show Memory Status" << endl;
        cout << " 6.  Start Watch               17. Close Task" << endl;
        cout << " 7.  Start Calendar            18. Start File Management" << endl;
        cout << " 8.  Start Expense Tracker     19. Switch Task" << endl;
        cout << " 9.  Start GPA Calculator     20. About PC" << endl;
        cout << " 10.  Start Math Quiz         21.SWITCH TO USER TO KERNAL MODE" << endl;
        cout << "11.  Start Minesweeper        22.EXIT" << endl; 
        
        cout << RESET;

        cout << MAGENTA << "==========================================================" << RESET << endl;
        cout << BOLD    << "|DEVELOPERS:          MURSALEEN    AND    TAHA           |" << RESET<<endl;  
        cout << MAGENTA << "==========================================================" << RESET << endl;
        cout << BOLD << " Enter your choice: " << RESET;
        cin >> choice;

        // DO NOT MODIFY THE FOLLOWING IF-ELSE STATEMENTS
        if (choice == "1") {
            bool started = os.startTask("notepad", 100, 10);
            
        }
        else if (choice == "2") {
            bool started = os.startTask("calculator", 50, 5);
          
        }
        else if (choice == "3") {
            bool started = os.startTask("memory", 150, 20);
          
        }
        else if (choice == "4") {
            bool started = os.startTask("todolist", 80, 10);
          
        }
        else if (choice == "5") {
            bool started = os.startTask("towerhanoi", 120, 15);
            
        }
        else if (choice == "6") {
            bool started = os.startTask("watch", 50, 5);
           
        }
        else if (choice == "7") {
            bool started = os.startTask("calendar", 60, 10);
           
        }
        else if (choice == "8") {
            bool started = os.startTask("expenseTracker", 70, 15);
           
        }
        else if (choice == "9") {
            bool started = os.startTask("gpa", 90, 20);
           
        }
        else if (choice == "10") {
            bool started = os.startTask("mathquiz", 80, 10);
           
        }
        else if (choice == "11") {
            bool started = os.startTask("minesweeper", 100, 20);
          
        }
        else if (choice == "12") {
            bool started = os.startTask("schoolsystem", 120, 25);
           
        }
        else if (choice == "13") {
            bool started = os.startTask("tiktac", 50, 5);
           
        }
        else if (choice == "14") {
            bool started = os.startTask("votingsystem", 70, 10);
           
        }
        else if (choice == "15") {
            os.showRunningTasks();
        }
        else if (choice == "16") {
            os.showMemoryStatus();
        }
        else if (choice == "17") {
            string taskName;
            cout << "Enter task name to close: ";
            cin >> taskName;
            os.closeTask(taskName);
        }
        else if (choice == "18") {
            bool started = os.startTask("filemanagement", 120, 25);
        }
        else if (choice == "19") {
            os.switchTask();
        }
        else if (choice == "20") {
            os.boot();
        }
        else if (choice == "22") {
            running = false;
            cout << GREEN << "\nExiting Mini OS. Goodbye!" << RESET << endl;
        }
        else if (choice == "21") {
            os.userToKernelMode();
        }
        
        else {
            cout << RED << "Invalid choice. Please try again." << RESET << endl;
        }
    }
    return 0;
}
