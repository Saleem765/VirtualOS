#include <iostream>
using namespace std;

int main() {
    const int P = 5; // Number of processes
    const int R = 3; // Number of resources

    int allocation[P][R] = {
        {0, 1, 0},
        {2, 0, 0},
        {3, 0, 2},
        {2, 1, 1},
        {0, 0, 2}
    };

    int max[P][R] = {
        {7, 5, 3},
        {3, 2, 2},
        {9, 0, 2},
        {2, 2, 2},
        {4, 3, 3}
    };

    int available[R] = {3, 3, 2};

    int need[P][R];
    for (int i = 0; i < P; i++)
        for (int j = 0; j < R; j++)
            need[i][j] = max[i][j] - allocation[i][j];

    bool finish[P] = {false};
    int safeSeq[P];
    int count = 0;

    while (count < P) {
        bool found = false;
        for (int i = 0; i < P; i++) {
            if (!finish[i]) {
                bool canExecute = true;
                for (int j = 0; j < R; j++) {
                    if (need[i][j] > available[j]) {
                        canExecute = false;
                        break;
                    }
                }

                if (canExecute) {
                    for (int j = 0; j < R; j++)
                        available[j] += allocation[i][j];

                    safeSeq[count++] = i;
                    finish[i] = true;
                    found = true;
                }
            }
        }

        if (!found) break;
    }

    if (count == P) {
        cout << "System is in a SAFE state.\nSafe sequence: ";
        for (int i = 0; i < P; i++) {
            cout << "P" << safeSeq[i];
            if (i != P - 1) cout << " -> ";
        }
        cout << endl;
    } else {
        cout << "System is in an UNSAFE state (deadlock may occur)." << endl;
    }

    return 0;
}
